<?php 	
	require_once 'config/config.php';
	$conexion = conexion($bd_config);
	$statement = $conexion->prepare('SELECT * FROM vw_comentario WHERE tipo_cometario="M" ');
	$statement->execute();
	$resultado = $statement->fetchAll();
?>

<!doctype html>
	<!-- Estructura interna del meta -->
	<?php include 'estructura/meta.php'; ?>

<body>
	<!-- Estructura interna del header -->
	<?php include 'estructura/header.php'; ?>
<div class="contenido">
	<br>
	<center><h1>COMENTARIOS MALOS</h1></center>
	<br>
	<table>
		<thead>
			<tr>
			<th>Id</th>
			<th>Cliente</th>
			<th>Tipo Comentario</th>
			<th>Asunto</th>
			<th>Comentario</th>
			<th>Fecha</th>
			<th>Estado</th>	
			</tr>			
		</thead>
		<tbody>
			<?php foreach ($resultado as $pedidos): ?>
				<tr>
					<td><?php echo $pedidos['id_comentario']; ?></td> 
					<td><?php echo $pedidos['nombre_cliente']; ?></td>
					<td><?php echo $pedidos['tipo_cometario']; ?></td>
					<td><?php echo $pedidos['asunto']; ?></td>
					<td><?php echo $pedidos['comentario']; ?></td>
					<td><?php echo $pedidos['fecha']; ?></td>
					<td><?php echo $pedidos['estado_comentario']; ?></td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
 <!-- Estructura interna del footer -->
	<?php include 'estructura/footer.php'; ?>

 <!-- Estructura interna del script -->
	<?php include 'estructura/script.php'; ?>
</body>
</html>