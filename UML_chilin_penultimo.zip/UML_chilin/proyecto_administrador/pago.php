<?php 
	require_once 'config/config.php';
	$conexion = conexion($bd_config);
	$statement = $conexion->prepare('SELECT * FROM vw_pago');
	$statement->execute();
	$resultado = $statement->fetchAll();

 ?>
<!doctype html>
	<!-- Estructura interna del meta -->
	<?php include 'estructura/meta.php'; ?>

<body>
	<!-- Estructura interna del header -->
	<?php include 'estructura/header.php'; ?>
<div class="contenido">
	<center><h1>PROCESAR PAGO DE PEDIDO:</h1></center>
	<br>
	<center><h1>PAGOS</h1></center>
	<br>
	<table>
		<thead>
			<tr>
			<th>Id</th>
			<th>Id factura</th>
			<th>Id cliente</th>
			<th>Cliente</th>
			<th>Fecha</th>
			<th>Pago</th>
			<th>Vuelto</th>
			<th>Estado</th>
			</tr>			
		</thead>
		<tbody>
			<?php foreach ($resultado as $pago): ?>
				<tr>
					<td><?php echo $pago['id_pago']; ?></td> 
					<td><?php echo $pago['id_factura']; ?></td>
					<td><?php echo $pago['id_cliente']; ?></td>
					<td><?php echo $pago['nombre_cliente']; ?></td>
					<td><?php echo $pago['fecha']; ?></td>
					<td><?php echo $pago['pago_cliente']; ?></td>
					<td><?php echo $pago['vuelto']; ?></td>
					<td><?php echo $pago['estado_pago']; ?></td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>



</div>
 <!-- Estructura interna del footer -->
	<?php include 'estructura/footer.php'; ?>

 <!-- Estructura interna del script -->
	<?php include 'estructura/script.php'; ?>
</body>

</html>

