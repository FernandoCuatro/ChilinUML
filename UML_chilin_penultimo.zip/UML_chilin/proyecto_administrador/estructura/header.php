<header>
			<img src="img/logo_arriba.png" alt="pupuseria">
	<nav id="menu_admin">
<ul>
  <li><a href="inicio.php">Inicio</a></li>
  <li><a href="productos.php">Productos</a>
    <ul>
      <li><a href="categoria.php">Categorías</a></li>
    </ul>
  </li>
  <li><a href="clientes.php">Clientes</a>
  </li>
  <li><a>Pedidos</a>
    <ul>
      <li><a href="pedidos_pendientes.php">Pedidos activos</a></li>
      <li><a href="pedidos_despachados.php">Pedidos inactivos</a></li>
    </ul>
  </li>
  <li><a href="comentario.php">Comentarios</a>
    <ul>
      <li><a href="comentario_bueno.php">Bueno</a></li>
      <li><a href="comentario_malos.php">Malo</a></li>
      <li><a href="comentario_reclamo.php">Reclamo</a></li>
    </ul>
  </li>
  <li><a href="facturas.php">Facturas</a>
    <ul>
      <li><a href="#">Pendientes</a></li>
      <li><a href="#">Canceladas</a></li>
    </ul>
  </li>
  <li><a href="pago.php">Pagos</a></li>
  <li><a href="#">Despachos</a></li>
  <li><a href="index.html">Cerrar sesión</a></li>
</ul>
</nav>
</header>