<?php 	
require_once 'config/config.php';
	$conexion = conexion($bd_config);
	$statement = $conexion->prepare('SELECT * FROM cliente');
	$statement->execute();
	$resultado = $statement->fetchAll();
?>
<!doctype html>
	<!-- Estructura interna del meta -->
	<?php include 'estructura/meta.php'; ?>

<body>
	<!-- Estructura interna del header -->
	<?php include 'estructura/header.php'; ?>
<br>
	<div class="contenido">
		<center><h1>CLIENTES</h1></center>
		<br>
		<table>
			<thead>
			<tr>
				<th>Id</th>
				<th>Nombre</th>
				<th>Apellido</th>
				<th>DUI</th>
				<th>Telefono</th>
				<th>Email</th>
				<th>Sexo</th>
				<th>Estado</th>
			</tr>
			</thead>
			<tbody>
				<?php foreach ($resultado as $cliente): ?>
				<tr>
					<td><?php echo $cliente['id_cliente']; ?></td>
					<td><?php echo $cliente['nombre_cliente']; ?></td>
					<td>
					<?php if ($cliente['apellido_cliente'] > '0'): ?>
							<?php echo $cliente['apellido_cliente']; ?>
							<?php else: ?>
								<?= "No disponible" ?>
						<?php endif ?>
					<td>
						<?php if ($cliente['dui'] > '0'): ?>
							<?php echo $cliente['dui']; ?>
							<?php else: ?>
								<?= "No disponible" ?>
						<?php endif ?>
						</td>
					<td><?php echo $cliente['telefono']; ?></td>
					<td><?php echo $cliente['correo']; ?></td>
					<td><?php echo $cliente['sexo']; ?></td>
					<td><?php echo $cliente['estado_cliente']; ?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>

 <!-- Estructura interna del footer -->
	<?php include 'estructura/footer.php'; ?>

 <!-- Estructura interna del script -->
	<?php include 'estructura/script.php'; ?>
</body>

</html>
















