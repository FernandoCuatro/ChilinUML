<?php
require_once '../config/config.php';

	$conexion = conexion($bd_config);

if($_SERVER['REQUEST_METHOD']=='POST'){
 $categoria   = $_POST['categoria'];
 $nombre      = $_POST['nombre'];
 $ingreso     = $_POST['ingreso'];
 $vencimiento = $_POST['vencimiento'];
 $costo       = $_POST['costo'];
 $precio      = $_POST['precio'];
 $stock       = $_POST['stock'];
 $estado      = $_POST['estado'];
 try {
 $statement=$conexion->prepare('call actualizar_producto(:id_categoria,:nombre_producto,:fecha_ingreso,:fecha_vencimiento,:costo,:precio,:stock,:estado_producto,:id)');
 $statement->execute(array(
  ':id_categoria'=>$categoria,
  ':nombre_producto'=>$nombre,
  ':fecha_ingreso'=>$ingreso,
  ':fecha_vencimiento'=>$vencimiento,
  ':costo'=>$costo,
  ':precio'=>$precio,
  ':stock'=>$stock,
  ':estado_producto'=>$estado,
  ':id'=>$_GET['producto'])
	);

	// call actualizar_producto('3','Frijol','12/12/2021','12/12/2021','0.56','0.75',4,'A','1')

 header('location: ../productos.php?datos=on');

 } catch (Exception $e) {
  header('location: ../productos.php?error=on');
 }
}

try {
	$statement = $conexion->prepare('SELECT
	categoria.id_categoria,
	producto.id_producto,
	categoria.nombre_categoria,
	producto.nombre_producto,
	producto.fecha_ingreso,
	producto.fecha_vencimiento,
	producto.costo,
	producto.precio,
	producto.stock,
	producto.estado_producto
 FROM producto
 Inner Join categoria ON producto.id_categoria = categoria.id_categoria WHERE id_producto = :id');
	$statement->execute(array(':id'=>$_GET['producto']));
	$resultado = $statement->fetch();	
} catch (Exception $e) {
	header('Location: ../index.html');
}

?>

<!doctype html>
<head>
  <meta charset="utf-8">
  <title>Administrador</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">

  <link rel="stylesheet" href="../css/normalize.css">
  <link rel="stylesheet" href="../css/main.css">
</head>
<body>

<div class="contenido">
<h1>Ingresar productos al sistema</h1>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="insertar" method="post">

	<div class="form-group">
		<label for="categoria">Categoria:</label>
		<input type="hidden" name="categoria" id="categoria" required="on" value="<?php echo $resultado['id_categoria'] ?>" readonly="on" >
		<input type="text" required="on" value="<?php echo $resultado['nombre_categoria'] ?>" readonly="on" >
	</div>

	<div class="form-group">
		<label for="nombre">Nombre del producto:</label>
		<input type="text" name="nombre" id="nombre" required="on" value="<?php echo $resultado['nombre_producto'] ?>">
	</div>

	<div class="form-group two">
		<label for="ingreso">Fecha de ingreso: </label>
		<input type="date" name="ingreso" id="ingreso" required="on" value="<?php echo $resultado['fecha_ingreso'] ?>">
	</div>

	<div class="form-group two">
		<label for="vencimiento">Fecha de vencimiento:</label>
		<input type="date" name="vencimiento" id="vencimiento" required="on" value="<?php echo $resultado['fecha_vencimiento'] ?>">
	</div>

	<div class="form-group four">
		<label for="costo">Costo:</label>
		<input type="number" name="costo" id="costo" required="on" min="0" step="0.01" value="<?php echo $resultado['costo'] ?>" >
	</div>

	<div class="form-group four">
		<label for="precio">Precio:</label>
		<input type="number" name="precio" id="precio" required="on" min="0" step="0.01" value="<?php echo $resultado['precio'] ?>">
	</div>

	<div class="form-group four">
		<label for="stock">Stock:</label>
		<input type="number" name="stock" id="stock" required="on" value="<?php echo $resultado['stock'] ?>" >
	</div>

	<div class="form-group">
		<label for="estado">Estado:</label>
		  <select name="estado" id="estado" required="on">
   	<option value="">Seleccione</option>
   	<option value="A">Activo</option>
   	<option value="I">Inactivo</option>
 </select>
	</div>

	<div class="enviar">
		<input type="submit" value="Modificar producto">
		<button><a href="../productos.php">Cancelar</a></button>
	</div>			

</form>

</div>

 <!-- Estructura interna del footer -->
	<?php include '../estructura/footer.php'; ?>

 <!-- Estructura interna del script -->
	<?php include '../estructura/script.php'; ?>
</body>

</html>