 <script src="js/vendor/modernizr-3.11.2.min.js"></script>
 <script src="js/plugins.js"></script>
 <script src="js/main.js"></script>
 <script src="https://kit.fontawesome.com/d21a3be417.js" crossorigin="anonymous"></script>