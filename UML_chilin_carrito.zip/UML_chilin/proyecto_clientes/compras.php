<?php
require_once 'config/config.php';
require_once 'config/funciones.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <!-- Estructura interna del meta -->
  <?php include 'estructura/meta.php'; ?>
</head> 
<body>
<div class="contenido">
	<?php include 'estructura/header.php'; ?>

	<!-- Modals necesarios para el usuario -->
	<?php include 'estructura/modals.php'; ?>

	<!-- carrito de compras para el usuario -->
	<?php include 'estructura/sidebar.php'; ?>

<?php 
comprobar_sesion(); 

	$obtener_pedido = conexion($bd_config)->prepare("SELECT * FROM pedido WHERE id_cliente = :id AND correlativo = correlativo");
	$obtener_pedido->execute(array(':id'=>$_SESSION['cliente']));
	$cargar_pedido = $obtener_pedido->fetchAll();

	// $obtener_factura = conexion($bd_config)->prepare("SELECT * FROM factura WHERE id_pedido = :id");
	// $obtener_factura->execute(array(':id'=>$_SESSION['cliente']));
	// $cargar_factura = $obtener_factura->fetchAll();

?>

	<div class="controles">
	 <h2 class="informacion_pedido">Hola <?php echo strtoupper($_SESSION['nombre']);?>, en este apartado, puedes ver el historial de las compras realizadas en nuestra pupuseria.
 </div>
	<div class="contenedor">

		<div class="compras">

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		<a href="detalles_compra.php">
				<div class="compra_informacion">
		   <div class="form-group compra">
			   <div class="form-two factr">000000000</div>
			   <div class="form-two factl">00-00-00 00:00</div>
			   <div class="form-two factr">Para llevar</div>
			   <div class="form-two factl">Pago total: $12.50</div>
			   <div class="form-two cmprlf">Cantidad de productos: 12</div>
			   <div class="form-two cmprrg"><i class="fas fa-plus-circle"></i></div>
		   </div>
				</div>
		</a>

		</div>





	<a href="index.php" class="volver bgsolido">Volver al inicio</a>
	</div>
</div>

 <!-- Estructura interna de footer -->
 <?php include 'estructura/footer.php'; ?>
 <!-- Estructura interna de script -->
 <?php include 'estructura/script.php'; ?>
</body>

</html>
