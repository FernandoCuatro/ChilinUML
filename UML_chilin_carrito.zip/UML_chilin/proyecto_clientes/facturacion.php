<?php
session_start();
require_once 'config/config.php';
require_once 'config/funciones.php';
comprobar_sesion();

// recuperamos el ultimo correlativo de la tabla de los pedidos
try {
 $statement_correlatico=conexion($bd_config)->prepare('SELECT correlativo FROM pedido ORDER by correlativo DESC LIMIT 1');
 $statement_correlatico->execute();
 $resultado_correlatico= $statement_correlatico->fetch();

 foreach ($_SESSION["carrito"] as $producto) {
 $statement=conexion($bd_config)->prepare('INSERT INTO pedido VALUES (NULL,:correlativo,:id_cliente,:id_producto,:cantidad,:estado)');
 $statement->execute(array(
  ':correlativo'=>($resultado_correlatico['correlativo'] + 1),
  ':id_cliente'=>$_SESSION['cliente'],
  ':id_producto'=>$producto['id_producto'],
  ':cantidad'=>$producto['cantidad'],
  ':estado'=>'A')
 );
	}

 $statement_id_pedido=conexion($bd_config)->prepare('SELECT id_pedido FROM pedido ORDER by 	id_pedido DESC LIMIT 1');
 $statement_id_pedido->execute();
 $resultado_id_pedido= $statement_id_pedido->fetch();


	$tot_pag=0; foreach ($_SESSION["carrito"] as $producto):	$tot_pag += number_format($producto['precio'] * $producto['cantidad'], 2); endforeach; $tot_pag =number_format($tot_pag, 2);

 $statement_factura=conexion($bd_config)->prepare('INSERT INTO factura VALUES (NULL, :id_pedido, :fecha, :hora, :total_pagar, :tipo_factura, :estado_factura)');
 $statement_factura->execute(array(
  ':id_pedido'=>$resultado_id_pedido['id_pedido'],
  ':fecha'=>$_POST['fecha'],
  ':hora'=>$_POST['hora'],
  ':total_pagar'=>$tot_pag,
  ':tipo_factura'=>'E',
  ':estado_factura'=>'A')
 );

} catch (Exception $e) {
  header('location:index.php?error=on');
}

	header('location:xcarrito.php?pedido=on');

?>
