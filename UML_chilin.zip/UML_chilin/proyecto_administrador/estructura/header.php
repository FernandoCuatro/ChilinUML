<header>
			<img src="img/logo_arriba.png" alt="pupuseria">
	<nav id="menu_admin">
<ul>
  <li><a href="inicio.php">Inicio</a></li>
  <li><a href="productos.php">Productos</a>
    <ul>
      <li><a href="#">Categorías</a></li>
    </ul>
  </li>
  <li><a href="#">Clientes</a>
    <ul>
      <li><a href="#">Listar clientes</a></li>
    </ul>
  </li>
  <li><a href="#">Pedidos</a>
    <ul>
      <li><a href="#">Pedidos pendientes para llevar</a></li>
      <li><a href="#">Pedidos pendientes para comer Aqui</a></li>
      <li><a href="#">Pedidos despachados</a></li>
    </ul>
  </li>
  <li><a href="#">Comentarios</a>
    <ul>
      <li><a href="#">Bueno</a></li>
      <li><a href="#">Malo</a></li>
      <li><a href="#">Reseña</a></li>
    </ul>
  </li>
  <li><a href="#">Facturas</a></li>
  <li><a href="#">Pagos</a></li>
  <li><a href="#">Cerrar sesión</a></li>
</ul>
</nav>
</header>