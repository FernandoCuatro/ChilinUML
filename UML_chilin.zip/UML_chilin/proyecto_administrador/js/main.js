function validacionCategoria(categoria) {

}