<?php 
require_once '../config/config.php';

	$conexion = conexion($bd_config);

try {
	$statement = $conexion->prepare('UPDATE producto SET estado_producto=:estado WHERE id_producto = :id');
	$statement->execute(array(':id'=>$_GET['producto'], ':estado'=>'I' ));
	$resultado = $statement->fetch();	

	header('Location: ../productos.php');

} catch (Exception $e) {
	header('Location: ../index.html');
}	

?>