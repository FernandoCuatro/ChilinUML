<?php
session_start();
require_once 'config/config.php';
require_once 'config/funciones.php';

	$conexion = conexion($bd_config);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <!-- Estructura interna del meta -->
  <?php include 'estructura/meta.php'; ?>
</head> 
<body>
	<div class="contenido">
	<?php include 'estructura/header.php'; ?>

	<!-- Modals necesarios para el usuario -->
	<?php include 'estructura/modals.php'; ?>

	<!-- Carrito de compras del usuario -->
	<?php include 'estructura/cart.php'; ?>

<?php
try {
	$categoria_1 = $conexion->prepare("
	SELECT categoria.nombre_categoria, categoria.estado_categoria, nombre_producto, precio 
	FROM producto 
	Inner Join categoria ON producto.id_categoria = categoria.id_categoria 
	WHERE producto.id_categoria = 1 AND estado_producto = 'A' AND categoria.estado_categoria = 'A' ");
$categoria_1->execute();
$productos_categoria_1 = $categoria_1->fetchAll();
} catch (Exception $e) {
	echo 'index.php?error=on';
}
?>

<?php if (count($productos_categoria_1) > 0): ?>
	<div class="controles">
	 <h2 class="categories-title controls">
 	<?php 
 	$categoria = explode(" ", $productos_categoria_1[0]['nombre_categoria']);
 	echo $categoria[1];
 	?>
 	</h2>
 <span class="control">
 	<button class="botones abrir" onclick="mostrarOcultar()">
 		<i class="fas fa-ellipsis-h"></i>
 </button>
	<button class="btn btn-demo botones carrito" type="button" data-toggle="modal" data-target="#myModal">
		0<i class="fas fa-shopping-cart"></i>
	</button>
 </span>
 </div>
	 <section class="carrousel first">
  <div class="carrousel-container">

		<div class="herramientas" id="herramientas">
			<div class="form-two">
				<a href="#">
					<button><i class="fas fa-ban"></i> Hacer reclamo</button>
				</a>
			</div>
			<div class="form-two">
				<a href="#">
					<button><i class="far fa-comment-alt"></i> Hacer comentario</button>
				</a>
			</div>
			<div class="form-two contrl">
				<a href="#">
					<button><i class="fas fa-history"></i> Historial compras</button>
				</a>
			</div>
			<div class="form-two contrl">
				<a href="#">
					<button><i class="fas fa-history"></i> Historial comentarios</button>
				</a>
			</div>
		</div>

	<?php foreach ($productos_categoria_1 as $productos): ?>
  <div class="carrousel-complemet">
   	<p class="pupusas-tittle"><?php echo $productos['nombre_producto']; ?></p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$<?php echo $productos['precio']; ?></p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>
 <?php endforeach ?>

  </div>
 </section>
<?php endif ?>

<?php
try {
$categoria_2 = $conexion->prepare("
	SELECT categoria.nombre_categoria, categoria.estado_categoria, nombre_producto, precio 
	FROM producto 
	Inner Join categoria ON producto.id_categoria = categoria.id_categoria 
	WHERE producto.id_categoria = 2 AND estado_producto = 'A' AND categoria.estado_categoria = 'A' ");
$categoria_2->execute();
$productos_categoria_2 = $categoria_2->fetchAll();
} catch (Exception $e) {
	echo 'index.php?error=on';
}
?>

<?php if (count($productos_categoria_2) > 0): ?>
 <h2 class="categories-title">
 	<?php 
 	$categoria = explode(" ", $productos_categoria_2[0]['nombre_categoria']);
 	echo $categoria[1];
 	?>
 		
 	</h2>
 <section class="carrousel">
  <div class="carrousel-container">

			<?php foreach ($productos_categoria_2 as $productos): ?>
		  <div class="carrousel-complemet">
		   	<p class="pupusas-tittle"><?php echo $productos['nombre_producto']; ?></p>
			   <div class="carrousel-item">
			   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
			   <div class="carrousel-item-details">
			    <div>
			    	<p class="carrousel-item-details--title">$<?php echo $productos['precio']; ?></p>
						 <div class="number-input-detail">
							 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
							 <input class="quantity" min="1" name="cantidad" value="1" type="number">
							 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
							</div>
							<div class="cart">
							<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
							</div>
			    </div>
			   </div>
			  </div>
		  </div>
		 <?php endforeach ?>

  </div>
 </section>
<?php endif ?>


 <h2 class="categories-title">Bebidas frias</h2>
 <section class="carrousel">
  <div class="carrousel-container">

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>
 
  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Ayote</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Chipilin</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  </div>
 </section>

	  
	</div>

 <!-- Estructura interna de footer -->
 <?php include 'estructura/footer.php'; ?>
 <!-- Estructura interna de script -->
 <?php include 'estructura/script.php'; ?>
</body>

</html>
