	<div class="modal left fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content carrito">

				<div class="modal-header encabezado">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<i class="fas fa-clipboard-list"></i>
					<img src="img/chilin.png" alt="Chilin">
					<h5 class="modal-title" id="myModalLabel">Lista de productos<br/>de su pedido</h5>
				</div>

				<div class="modal-body">

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa frijol con queso</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa frijol con queso</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

					<div class="listado">
						<div class="lista"><img src="img/pupusas.jpg" alt="Pupusa"></div>
						<div class="lista"><p class="titulo">Pupusa revuelta</p></div>
						<div class="lista"><p>Cantidad: 1</p></div>
						<div class="lista"><button type="submit">Eliminar</button></div>
					</div>

				</div>

   <div class="modal-footer">
   	<?php if (isset($_SESSION['cliente'])): ?>
	    <button type="button" class="proceso">Procesar pedido</button>
	    <?php else: ?>
	    	<a href="login.php">Inicie sesión para procesar el pedido</a>
	    <?php endif ?>
	  </div>

			</div>
		</div>
	</div>

<style type="text/css">
.modal.left .modal-dialog {
	position: fixed;
	margin: auto;
	width: 50%;
	height: 100%;
	-webkit-transform: translate3d(0%, 0, 0);
 -ms-transform: translate3d(0%, 0, 0);
 -o-transform: translate3d(0%, 0, 0);
 transform: translate3d(0%, 0, 0);
}
.modal.left .modal-content {
	height: 100%;
	overflow-y: auto;
}
.modal.left .modal-body {
	padding: 15px 15px 0px;
}
.modal.left.fade .modal-dialog{
	left: -320px;
	-webkit-transition: opacity 0.3s linear, left 0.3s ease-out;
 -moz-transition: opacity 0.3s linear, left 0.3s ease-out;
 -o-transition: opacity 0.3s linear, left 0.3s ease-out;
 transition: opacity 0.3s linear, left 0.3s ease-out;
}
.modal.left.fade.in .modal-dialog{
	left: 0;
}
.carrito {
	border-radius: 0;
	border-right: 5px solid #000;
}
div.encabezado {
	font-size: 2.0em;
	padding-bottom: 0px;
}
div.encabezado img {
	width: 60%;
}
h5.modal-title {
	font-weight: bold;
	text-transform: none;
}
div.modal-footer
{
	text-align: center;
	border-top: none;
}
button.proceso {
	background-color: #f6a11b;
	border: none;
	padding: 5px 10px;
	border-radius: 5px;
	text-transform: uppercase;
}
div.listado{
	width: 100%;
	height: 80px;
	margin: 10px 0px;
}
div.lista{
	width: 40%;
	float: left;
}
div.listado img{
	width: 75%;
 margin: 0px auto;
}
	div.listado p{
	font-size: .6em;
	margin: 0px auto;
}
div.listado p.titulo{
	font-size: .7em;
	margin: 0px auto;
}
div.listado button{
	border:none;
	font-size: .8em;
	border-radius: 3px;
 padding: 3px 1px;
	background-color: red;
}

</style>