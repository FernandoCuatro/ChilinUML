<style type="text/css">
/* ============================== Modals (Estilos personalizados) ============================== */
div.modal-header {border-bottom: none;}
div.centrado {top: 35%;}
div.modal {font-family: 'Poppins', sans-serif; text-transform: uppercase; font-weight: bold; font-size: 0.5em; text-align: center; position: absolute;}
div.modal-body img{width: 70px; margin-top: -50px; padding-bottom: 10px;}
</style>

<?php if (isset($_GET["datos"]) == "on"): ?>
<div class="modal-dialog modal fade modal-dialog centrado" id="myModal" role="dialog">
	<div class="modal-dialog">
	<div class="modal-content">
	  <div class="modal-header">
	    <button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>
	  <div class="modal-body">
	  	<img src="img/de-acuerdo.png" alt="Exito">
	    <p>Sus datos se guardaron<br/>correctamente</p>
	  </div>
	</div>
	</div>
</div>
<?php endif ?>
