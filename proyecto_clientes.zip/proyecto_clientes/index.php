<?php
session_start();
require_once 'config/config.php';
require_once 'config/funciones.php';

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <!-- Estructura interna del meta -->
  <?php include 'estructura/meta.php'; ?>
</head> 
<body>
	<div class="contenido">
	<?php include 'estructura/header.php'; ?>

	<!-- Modals necesarios para el usuario -->
	<?php include 'estructura/modals.php'; ?>

<div class="control">
	<div class="abrir-controles">
		<button><i class="fas fa-ellipsis-h"></i></button>
	</div>
	<div class="open-cart">
		<button><i class="fas fa-shopping-cart"></i></button>
	</div>
</div>

<div class="controles">
	
</div>

 <h2 class="categories-title">Pupusas</h2>
 <section class="carrousel">
  <div class="carrousel-container">

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>
 
  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.85</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button onclick="alert('le dio click a agregar')"><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  </div>
 </section>

 <h2 class="categories-title">Especialidades</h2>
 <section class="carrousel">
  <div class="carrousel-container">

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol y queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Revuelta</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Chicharrón</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>
 
  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Frijol</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Queso</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Jalapeño</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Ayote</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Chipilin</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/pupusas.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  </div>
 </section>

 <h2 class="categories-title">Bebidas frias</h2>
 <section class="carrousel">
  <div class="carrousel-container">

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
	    	<p class="carrousel-item-details--title">$0.45</p>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>
 
  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Horchata</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Ayote</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  <div class="carrousel-complemet">
   	<p class="pupusas-tittle">Chipilin</p>
	   <div class="carrousel-item">
	   <img class="carrousel-item-img" src="img/horchata.jpg" alt="Fresas">
	   <div class="carrousel-item-details">
	    <div>
				 <div class="number-input-detail">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" ></button>
					 <input class="quantity" min="1" name="cantidad" value="1" type="number">
					 <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
					</div>
					<div class="cart">
					<button><i class="fas fa-shopping-cart"></i></button>
					</div>
	    </div>
	   </div>
	  </div>
  </div>

  </div>
 </section>

	  
	</div>

 <!-- Estructura interna de footer -->
 <?php include 'estructura/footer.php'; ?>
 <!-- Estructura interna de script -->
 <?php include 'estructura/script.php'; ?>
</body>

</html>
